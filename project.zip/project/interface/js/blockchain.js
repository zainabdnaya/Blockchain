   //If I take accessToMetamask function part out, then the code will still work. 
   //However I will not be able to call a write method. Because I would not have an 
   //account to send gas.
   let account;
   let provider
   const accessToMetamask = async() => {
           if (window.ethereum !== "undefined") {
               provider = new ethers.providers.Web3Provider(window.ethereum);
               const accounts = await ethereum.request({
                   method: "eth_requestAccounts"
               });
               account = accounts[0];
               document.getElementById("accountArea").innerHTML = account;
           }
       }
       // read the file uploaded by the user
   async function readSingleFile(e) {
       var file = document.getElementById("fileupload").files[0];
       if (!file) {
           return;
       }
       var reader = new FileReader();
       var textFile = "";
       reader.onload = async function(e) {
           var contents = e.target.result;
           // displayContents(contents);
           console.log(contents);
           textFile = contents;
           const signature = await ethereum.request({
               method: 'personal_sign',
               params: [textFile, account],
           });
           console.log(signature);
           document.getElementById("signArea").innerHTML = signature;
           return contents;
       };
       reader.readAsText(file);
       return textFile;
   }
   // sign docs 
   const signDocument = async() => {
       readSingleFile(null)
   }
   const verifyDocument = async() => {
       const signature = document.getElementById("signArea").innerHTML;
       const file = document.getElementById("fileupload").files[0];
       const reader = new FileReader();
       reader.onload = async function(e) {
           const contents = e.target.result;
           const recovered = await ethereum.request({
               method: 'personal_ecRecover',
               params: [contents, signature],
           });
           console.log(recovered);
           document.getElementById("verifyArea").innerHTML = recovered;
       };
       reader.readAsText(file);
   }
   const PublishDocument = async() => {
       var addressContract = "0x5fb97c2115bccc99261760007309ebb78a26cee7e64477ca16aad89d75950f91";
       // using remix to deploy the contract
       var abi = [{
           "inputs": [{
               "internalType": "string",
               "name": "documentHash",
               "type": "string"
           }],
           "name": "addDocument",
           "outputs": [],
           "stateMutability": "nonpayable",
           "type": "function"
       }, {
           "inputs": [],
           "name": "admin",
           "outputs": [{
               "internalType": "address",
               "name": "",
               "type": "address"
           }],
           "stateMutability": "view",
           "type": "function"
       }, {
           "inputs": [{
               "internalType": "string",
               "name": "",
               "type": "string"
           }],
           "name": "documents",
           "outputs": [{
               "internalType": "uint256",
               "name": "",
               "type": "uint256"
           }],
           "stateMutability": "view",
           "type": "function"
       }, {
           "inputs": [{
               "internalType": "string",
               "name": "documentHash",
               "type": "string"
           }],
           "name": "getDate",
           "outputs": [{
               "internalType": "uint256",
               "name": "",
               "type": "uint256"
           }],
           "stateMutability": "view",
           "type": "function"
       }]

       var signer = provider.getSigner();
       var contract = new ethers.Contract(addressContract, abi, signer);
       const signature = document.getElementById("signArea").innerHTML;

       // check if contract is deployed
       const code = await provider.getCode(addressContract);
       if (code === "0x") {
           console.log("Contract not deployed");
           return;
       }
       // add string to contract
       const tx = await contract.addDocument(signature);
       await tx.wait();
       document.getElementById("publishArea").innerHTML = "Document published";
   }